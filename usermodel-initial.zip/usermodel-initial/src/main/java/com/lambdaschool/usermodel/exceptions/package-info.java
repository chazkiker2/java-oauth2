/**
 * Contains the exceptions that are used in this application
 *
 * @author John Mitchell (john@lambdaschool.com) with Lambda School unless otherwise noted.
 */
package com.lambdaschool.usermodel.exceptions;