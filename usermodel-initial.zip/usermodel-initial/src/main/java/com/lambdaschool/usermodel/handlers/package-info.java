/**
 * Contains handlers, advisors, that are used throughout the application
 *
 * @author John Mitchell (john@lambdaschool.com) with Lambda School unless otherwise noted.
 */
package com.lambdaschool.usermodel.handlers;